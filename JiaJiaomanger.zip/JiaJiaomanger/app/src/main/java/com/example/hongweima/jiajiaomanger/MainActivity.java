package com.example.hongweima.jiajiaomanger;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //创建或者打开数据库，数据表
        MyDBOpenHelper db = new MyDBOpenHelper(MainActivity.this);
        db.getReadableDatabase();
    }
}
