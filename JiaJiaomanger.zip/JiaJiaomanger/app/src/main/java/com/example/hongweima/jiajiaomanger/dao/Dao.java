package com.example.hongweima.jiajiaomanger.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.hongweima.jiajiaomanger.MyDBOpenHelper;

/**
 * Created by HongweiMa on 2018/6/18.
 */

public class Dao {
    private MyDBOpenHelper helper;

    public Dao(Context context) {

        helper = new MyDBOpenHelper(context);
    }
    //添加一条记录
    public void add(String uname,String upassword,String name,String usex,String uimg,String ugrade,
                    String ucourse,String usynopsis,String uphone,String uaddress){
        SQLiteDatabase db = helper.getReadableDatabase();
        db.execSQL("insert into user(uname,upassword,name,usex,uimg,ugrade,ucourse,uphone,uaddress)" +
                "values(?,?,?,?,?,?,?,?,?);",new Object[]{uname,upassword,name,usex,uimg,ugrade,ucourse,uphone,uaddress});
        db.close();
    }
    //删除一条记录
    public void delete(String uname){
        SQLiteDatabase db = helper.getReadableDatabase();
        db.execSQL("delete from user where _username=?",new Object[]{uname});
        db.close();
    }
    //修改一条记录
    public void update(String uname,String upassword,String unumber,String uaddress){
        SQLiteDatabase db = helper.getReadableDatabase();
        db.execSQL("update user set upassword=?,unumber=?,uaddress=? where uname = ?",
                new Object[]{upassword,unumber,uaddress,uname});
        db.close();
    }
    //查询一条记录
    public String query(String uname,String upassword,String name,String unumber,String uaddress){
        SQLiteDatabase db = helper.getReadableDatabase();

//        db.rawQuery()

        Cursor cursor=db.rawQuery("select upassword from user where name = ?",new String[]{name});
//        db.execSQL("select upassword,name, unumber,uaddress from user where uname = ?",new Object[]{upassword,name,unumber,uaddress,uname});
        String password =null;
        if(cursor.moveToNext()){
            password=cursor.getString(0);
        }
        cursor.close();
        db.close();
        return password;
    }
}
