package com.example.hongweima.jiajiaomanger;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by HongweiMa on 2018/6/18.
 */


public class MyDBOpenHelper extends SQLiteOpenHelper {
/*
    context表示上下文；
    name表示数据库名称；
    null表示默认的游标；
    1 是版本号，版本号只能变大不能变小；
 */
    public MyDBOpenHelper(Context context) {
        super(context,"jiajiaomanger.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table user(_id integer primary key autoincrement,uname varchar(20),upassword varchar(20)," +
                " name varchar(20)," +
                " usex varchar(4),uimg varchar(20),ugrade varchar(10),ucourse varchar(10),usynopsis varchar(100)," +
                " uphone varchar(20),uaddress varchar(20))");
        System.out.println("创建数据表成功");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        System.out.print("数据库更新");
    }
}
